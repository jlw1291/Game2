using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace InventoryReasource{
	public class InventoryReasourceClass
	{

		public string Name;
		//public GameObject = Go;

	    public InventoryReasourceClass(string name)
	    {
	        Debug.Log("Creating: " + name);
	        this.Name = name;
	        //this.Go = 
	    }
	}
}