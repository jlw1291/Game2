# Game2
MSU Game Design: Team Idylshire's Game 2 Development project.
